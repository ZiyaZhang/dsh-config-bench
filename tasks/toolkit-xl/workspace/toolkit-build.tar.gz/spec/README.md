# toolkit — specification

`toolkit` is a Python package made of three sub-packages with four modules
each, one facade per sub-package, and a small command line. This file gives
the layout, the rules that apply everywhere, and the command line. Every
module and every facade has its own specification file next to this one.

## 1. Layout

```
toolkit/
  __init__.py          may be empty
  __main__.py          command line                  -> section 4 of this file
  text/__init__.py     facade of toolkit.text        -> spec/text/PACKAGE.md
  text/wrap.py         word wrapping                 -> spec/text/wrap.md
  text/table.py        plain-text tables             -> spec/text/table.md
  text/slug.py         URL slugs                     -> spec/text/slug.md
  text/template.py     mini template language        -> spec/text/template.md
  data/__init__.py     facade of toolkit.data        -> spec/data/PACKAGE.md
  data/csvlite.py      CSV parsing and formatting    -> spec/data/csvlite.md
  data/ini.py          INI parsing                   -> spec/data/ini.md
  data/jsonpath.py     JSONPath subset               -> spec/data/jsonpath.md
  data/diff.py         line diff                     -> spec/data/diff.md
  calc/__init__.py     facade of toolkit.calc        -> spec/calc/PACKAGE.md
  calc/stats.py        descriptive statistics        -> spec/calc/stats.md
  calc/intervals.py    closed integer intervals      -> spec/calc/intervals.md
  calc/units.py        quantities and unit conversion-> spec/calc/units.md
  calc/expr.py         arithmetic expressions        -> spec/calc/expr.md
```

## 2. Rules that apply everywhere

G1. **Python.** The code runs on Python 3.12 and uses only the standard
library.

G2. **Dependencies.** A module of a sub-package does not import the other
modules of that sub-package; only the sub-package's `__init__.py` imports
them. The sub-packages do not import each other. `toolkit/__main__.py` may
import all three sub-packages.

G3. **Public names.** Each specification lists the public names of its
module with their exact signatures (parameter names, order and defaults).
Tests call parameters both by position and by keyword.

G4. **No side effects.** Functions never modify their arguments, never print
and never read or write files. Only `toolkit/__main__.py` reads standard
input and writes to standard output and standard error.

G5. **Text.** The length of a string is `len(string)`, i.e. the number of
code points; display width is not considered. Text is used exactly as given:
no trimming, no case change and no Unicode normalisation unless a rule says
so. "Whitespace" means the characters for which `str.isspace()` is true.

G6. **Result types.** "list" means a `list`, "tuple" means a `tuple`, "dict"
means a `dict`; results are compared with `==` against values of exactly
these types. A result described as a float must have the type `float`, and
a result described as an `int`, `bool` or `str` must have that type; some
tests check `type(result)`.

G7. **Floats.** Tests compare floating-point results with a tolerance of
`1e-9` (relative or absolute). Only where a result involves no rounding at
all (`float("3.5")`, `1.0 + 2.0`, the mean of 2, 4 and 6) may a test compare
it exactly. Text produced from floats is compared exactly, and the
specifications give the formatting rule wherever that happens.

G8. **Errors.** The exception type is part of the contract; the message is
not (tests never look at it). The custom exception classes are subclasses of
`ValueError` and are defined in the module whose specification introduces
them. When one call violates several rules and the specification gives no
order, any of the listed exceptions may be raised; tests do not contain such
calls. Arguments of a wrong type are only tested where a rule names the
exception to raise.

## 3. How the code is tested

Tests import the modules by their full names (`toolkit.text.wrap`,
`toolkit.calc.expr`, ...) and the facades as `toolkit.text`, `toolkit.data`
and `toolkit.calc`. The command line is run as `python -m toolkit ...` in a
child process whose working directory is the directory that contains the
`toolkit` package. The tests need no network access, no clock and no
randomness.

## 4. Command line

`toolkit/__main__.py` defines `main(argv=None)`, which runs the command line
for the argument list `argv` (`None` means `sys.argv[1:]`) and returns the
exit status as an `int` for the outcomes "success" and "handled error" below.
The file ends with

```python
if __name__ == "__main__":
    sys.exit(main())
```

There are three subcommands, one per sub-package.

### 4.1 `python -m toolkit text`

Takes no further arguments. Reads all of standard input and splits it into
lines with `str.splitlines()`. Every line is stripped with `str.strip()`;
lines that are empty after stripping are dropped. The remaining strings, in
order, are the titles. Writes `toolkit.text.toc(titles)` followed by one
`"\n"` to standard output. Empty input gives an empty list of titles, which
is not an error.

```
$ printf 'Getting Started\n\n  FAQ  \nFAQ\n' | python -m toolkit text
| # | Title           | Anchor           |
|---|-----------------|------------------|
| 1 | Getting Started | #getting-started |
| 2 | FAQ             | #faq             |
| 3 | FAQ             | #faq-2           |
```

### 4.2 `python -m toolkit data FORMAT PATH`

Reads all of standard input as the document text and computes
`toolkit.data.query(document, PATH, FORMAT)`. For every match, in order, it
writes one line to standard output: `json.dumps(match, sort_keys=True)` (all
other `json.dumps` parameters at their defaults) followed by `"\n"`. With no
matches nothing is written; that is still a success.

Handled errors: any `ValueError` raised by `query` — an unknown `FORMAT`,
`CSVError`, `INIError`, `JSONPathError`.

```
$ printf 'name,age\nann,3\nbob,5\n' | python -m toolkit data csv '$[*].name'
"ann"
"bob"
$ printf 'name,age\nann,3\n' | python -m toolkit data csv '$[0]'
{"age": "3", "name": "ann"}
$ printf '[server]\nport = 8080\ndebug = no\n' | python -m toolkit data ini '$.server.*'
8080
false
```

### 4.3 `python -m toolkit calc EXPRESSION [NAME=VALUE ...]`

Does not read standard input. Every argument after `EXPRESSION` is a variable
assignment. It is split at its first `=` into `NAME` and `VALUE`; the
variable `NAME` gets the value `float(VALUE)`. If the same name is assigned
twice, the last assignment wins. Writes
`toolkit.calc.format_number(toolkit.calc.evaluate(EXPRESSION, variables), 6)`
followed by one `"\n"` to standard output.

Handled errors: an assignment without `=`, with an empty `NAME`, or whose
`VALUE` makes `float()` raise `ValueError`; `ExprError` (including its
subclasses) and `ZeroDivisionError` raised by `evaluate`.

```
$ python -m toolkit calc '2 * x + 1' x=3
7
$ python -m toolkit calc '1 / 3'
0.333333
$ python -m toolkit calc 'sqrt(a ^ 2 + b ^ 2)' a=3 b=4
5
```

### 4.4 Exit status and output streams

| Outcome | Exit status | Standard output | Standard error |
|---|---|---|---|
| success | 0 | as specified above | not checked |
| handled error (listed per subcommand) | 1 | empty | exactly one line that starts with `error: ` (the rest of the line is free) |
| usage error | 2 | empty | not checked |

Usage errors are: no subcommand, an unknown subcommand, and a wrong number of
positional arguments (`text` with any argument, `data` with fewer or more
than two, `calc` without `EXPRESSION`).

Arguments that begin with `-` are never used by the tests; their treatment
is free (this allows `argparse` with its default options).
