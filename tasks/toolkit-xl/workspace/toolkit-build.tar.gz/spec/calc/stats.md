# toolkit.calc.stats — descriptive statistics

File: `toolkit/calc/stats.py`. Public names: `mean`, `median`, `mode`,
`percentile`, `variance`, `stdev`. The global rules of `spec/README.md`
apply.

## Input rules (all functions)

I1. `values` is any iterable of numbers (list, tuple, generator, ...). It is
read once and never modified.

I2. `TypeError` if any element is not an `int` or a `float`. A `bool` is not
accepted as a number: it raises `TypeError` too.

I3. `ValueError` if `values` has no elements.

## mean(values)

Returns the arithmetic mean (sum divided by count) as a float, also when the
values are integers and the mean is a whole number (`mean([2, 4, 6])` is
`4.0`).

## median(values)

Returns the median as a float: with the values sorted in ascending order,
the middle value converted with `float()` if the count is odd, and the mean
of the two middle values if the count is even (`median([3, 1, 2])` is `2.0`).

## mode(values)

Returns the value that occurs most often. If several values occur equally
often, the smallest of them is returned. The value is returned as it is in
the input (an `int` stays an `int`, it is not converted to float). Values
that are equal count as the same value (`1` and `1.0`); the first occurrence
in the input is the one returned.

## percentile(values, p)

Returns the `p`-th percentile as a float, with linear interpolation between
the two closest ranks.

P1. `ValueError` if `p < 0` or `p > 100`. `p` may be an `int` or a `float`.

P2. Let `x[0] <= x[1] <= ... <= x[n-1]` be the values in ascending order,
`rank = (p / 100) * (n - 1)`, `k = floor(rank)` and `f = rank - k`.
If `f == 0` the result is `float(x[k])`; otherwise it is
`x[k] + f * (x[k+1] - x[k])`. Either way the result is a float.

So `percentile(values, 0)` is the minimum, `percentile(values, 100)` the
maximum and `percentile(values, 50)` the median.

## variance(values, sample=False)

Returns the variance as a float. With `m` the mean and `n` the count, let
`ss` be the sum of `(x - m) ** 2` over all values.

- `sample=False` (default): the population variance `ss / n`.
- `sample=True`: the sample variance `ss / (n - 1)`; `ValueError` if `n < 2`.

## stdev(values, sample=False)

Returns the square root of `variance(values, sample)` as a float; the same
errors apply.

## Examples

```python
>>> from toolkit.calc.stats import mean, median, mode, percentile, variance, stdev
>>> mean([1, 2, 3, 4])
2.5
>>> median([5, 1, 3]), median([4, 1, 3, 2])
(3.0, 2.5)
>>> mode([3, 1, 3, 2, 1]), mode([7, 8, 9])
(1, 7)
>>> percentile([10, 20, 30, 40], 25), percentile([10, 20, 30, 40], 100)
(17.5, 40.0)
>>> variance([2, 4, 4, 4, 5, 5, 7, 9]), stdev([2, 4, 4, 4, 5, 5, 7, 9])
(4.0, 2.0)
>>> variance([1, 2, 3, 4], sample=True)
1.6666666666666667
```

In the fourth example `rank = 0.25 * 3 = 0.75`, so the result is
`10 + 0.75 * (20 - 10)`.

Raised errors, for example: `mean([])` raises `ValueError`;
`median([1, "2"])` and `mean([True, 2])` raise `TypeError`;
`percentile([1, 2], 101)` and `stdev([5], sample=True)` raise `ValueError`.
