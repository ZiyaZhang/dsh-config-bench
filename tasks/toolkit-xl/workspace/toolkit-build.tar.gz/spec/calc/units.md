# toolkit.calc.units — quantities and unit conversion

File: `toolkit/calc/units.py`. Public names: `parse_quantity`, `unit_family`,
`convert`, `format_number`, `format_quantity`, `convert_text`, `UnitError`.
The global rules of `spec/README.md` apply.

`UnitError` is a subclass of `ValueError`, defined in this module.

## Units

A unit is written as its symbol. Symbols are case-sensitive (`km` is a unit,
`KM` and `Km` are not). Each unit belongs to one family and has a factor: the
size of one unit expressed in the base unit of its family.

| Family | Symbol and factor |
|---|---|
| `length` (base: metre) | `mm` 0.001, `cm` 0.01, `m` 1, `km` 1000, `in` 0.0254, `ft` 0.3048, `yd` 0.9144, `mi` 1609.344 |
| `mass` (base: gram) | `mg` 0.001, `g` 1, `kg` 1000, `t` 1000000, `oz` 28.349523125, `lb` 453.59237 |
| `time` (base: second) | `ms` 0.001, `s` 1, `min` 60, `h` 3600, `d` 86400, `wk` 604800 |

These 20 symbols are the only units.

## unit_family(unit)

Returns `"length"`, `"mass"` or `"time"` for a unit symbol. `UnitError` for
any other string.

## parse_quantity(text)

Returns the tuple `(value, unit)`: `value` is a float, `unit` the symbol.

Q1. `text.strip()` must fully match: a number, then optional whitespace
(regular expression `\s*`), then a unit word.

- number: `[+-]?([0-9]+(\.[0-9]*)?|\.[0-9]+)` — an optional sign, then digits
  with an optional dot and optional further digits, or a dot followed by
  digits. Exponent notation is not allowed.
- unit word: `[A-Za-z]+`.

Otherwise: `UnitError`.

Q2. `UnitError` if the unit word is not one of the 20 symbols.

Q3. `value` is `float(number)`.

## convert(value, from_unit, to_unit)

Returns `value * factor(from_unit) / factor(to_unit)` as a float.
`UnitError` if either unit is unknown, or if the two units belong to
different families.

## format_number(value, precision=3)

Returns a number as text with at most `precision` decimal places and no
trailing zeros.

N1. `ValueError` if `precision < 0`.

N2. Start with `format(value, ".{precision}f")`, i.e. fixed-point notation
with exactly `precision` decimal places (for `precision` 3: `format(value,
".3f")`). `value` may be an `int` or a `float`.

N3. If that text contains a `.`: remove all `0` characters from its end,
then remove a `.` from its end if there is one.

N4. If the text is now `-0`, the result is `0`.

## format_quantity(value, unit, precision=3)

Returns `format_number(value, precision) + " " + unit`. `UnitError` if
`unit` is not one of the 20 symbols.

## convert_text(text, to_unit, precision=3)

With `(value, unit) = parse_quantity(text)`, returns
`format_quantity(convert(value, unit, to_unit), to_unit, precision)`. The
errors of the functions used are raised unchanged.

## Examples

```python
>>> from toolkit.calc.units import parse_quantity, unit_family, convert, format_number, format_quantity, convert_text
>>> parse_quantity("3.5 km"), parse_quantity(" -12kg "), parse_quantity(".5   h")
((3.5, 'km'), (-12.0, 'kg'), (0.5, 'h'))
>>> unit_family("mi"), unit_family("oz"), unit_family("min")
('length', 'mass', 'time')
>>> convert(3.5, "km", "m"), convert(90, "min", "h")
(3500.0, 1.5)
>>> format_number(3500.0), format_number(2.5), format_number(1.23456), format_number(1.23456, 1)
('3500', '2.5', '1.235', '1.2')
>>> format_number(-0.0001), format_number(1200, 0), format_number(7, 2)
('0', '1200', '7')
>>> format_quantity(1.609344, "km"), format_quantity(12, "ft", precision=1)
('1.609 km', '12 ft')
>>> convert_text("3.5 km", "m"), convert_text("1 lb", "g", 2), convert_text("36 in", "yd")
('3500 m', '453.59 g', '1 yd')
```

Raised errors, for example: `parse_quantity("3.5")`, `parse_quantity("km")`,
`parse_quantity("1e3 m")`, `parse_quantity("5 KM")`,
`parse_quantity("5 parsec")`, `unit_family("parsec")` and
`convert(1, "kg", "m")` raise `UnitError`; `format_number(1.5, -1)` raises
`ValueError`.
