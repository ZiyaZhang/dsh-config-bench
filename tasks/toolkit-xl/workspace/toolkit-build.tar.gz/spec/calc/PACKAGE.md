# toolkit.calc — package facade

File: `toolkit/calc/__init__.py`. The global rules of `spec/README.md` apply.

## Re-exports

The facade imports its four modules and re-exports these names (the very
same objects), so that for example `toolkit.calc.evaluate` is
`toolkit.calc.expr.evaluate`:

| From module | Names |
|---|---|
| `toolkit.calc.stats` | `mean`, `median`, `mode`, `percentile`, `variance`, `stdev` |
| `toolkit.calc.intervals` | `merge_intervals`, `intersect_intervals`, `subtract_intervals`, `count_points` |
| `toolkit.calc.units` | `parse_quantity`, `unit_family`, `convert`, `format_number`, `format_quantity`, `convert_text`, `UnitError` |
| `toolkit.calc.expr` | `evaluate`, `ExprError`, `ExprSyntaxError`, `ExprNameError` |

`__all__` lists these twenty-one names and `stat_expr` (the order is free).

## stat_expr(expression, values)

Evaluates an arithmetic expression in which the statistics of `values` are
available as variables, and returns the result as a float.

S1. `values` is any iterable of numbers; it is read once. The input rules of
`toolkit.calc.stats` apply: `TypeError` if an element is not an `int` or a
`float` (a `bool` is not accepted), `ValueError` if there are no elements.

S2. These seven variables are defined, all as floats:

| Variable | Value |
|---|---|
| `n` | the number of values |
| `total` | the sum of the values |
| `mean` | `mean(values)` |
| `median` | `median(values)` |
| `stdev` | `stdev(values)` — the population standard deviation |
| `lo` | the smallest value |
| `hi` | the largest value |

S3. The result is `evaluate(expression, variables)` with exactly these
variables. Everything in `spec/calc/expr.md` applies: the constants `pi` and
`e`, the functions, and the errors (`ExprSyntaxError`, `ExprNameError`,
`ExprError`, `ZeroDivisionError`), which are raised unchanged.

```python
>>> from toolkit.calc import stat_expr
>>> stat_expr("mean", [1, 2, 3, 4])
2.5
>>> stat_expr("mean + 2 * stdev", [2, 4, 4, 4, 5, 5, 7, 9])
9.0
>>> stat_expr("(hi - lo) / n", [10, 4, 7])
2.0
>>> stat_expr("total - median", [10, 4, 7])
14.0
```
