# toolkit.calc.expr — arithmetic expressions

File: `toolkit/calc/expr.py`. Public names: `evaluate`, `ExprError`,
`ExprSyntaxError`, `ExprNameError`. The global rules of `spec/README.md`
apply.

Exception classes, all defined in this module:

- `ExprError`, a subclass of `ValueError`;
- `ExprSyntaxError`, a subclass of `ExprError`: the expression is malformed;
- `ExprNameError`, a subclass of `ExprError`: an unknown variable or function.

## evaluate(expression, variables=None)

Evaluates the arithmetic expression in the string `expression` and returns
the result as a float. `variables` is `None` or a dict that maps variable
names to numbers (`int` or `float`).

### Tokens

X1. The expression is split into tokens from left to right; at each position
the longest possible token is taken. Whitespace is not a token: it is skipped
wherever it occurs (before, between and after tokens).

- number: `[0-9]+(\.[0-9]*)?|\.[0-9]+` — digits with an optional dot and
  optional further digits (`12`, `1.5`, `3.`), or a dot followed by digits
  (`.5`). There is no exponent notation and a number token has no sign.
- name: `[A-Za-z_][A-Za-z0-9_]*`
- the single characters `+` `-` `*` `/` `%` `^` `(` `)` `,`

Any other character raises `ExprSyntaxError`.

### Grammar

X2. The tokens must form exactly one `expression`:

```
expression := term (("+" | "-") term)*
term       := unary (("*" | "/" | "%") unary)*
unary      := ("+" | "-") unary | power
power      := atom ("^" unary)?
atom       := number
            | name
            | name "(" [expression ("," expression)*] ")"
            | "(" expression ")"
```

Otherwise `ExprSyntaxError` is raised: for an empty expression (no tokens),
a missing operand, a missing or surplus parenthesis, tokens left over after
the expression, two operands in a row (`2 x`, `2 (3)` — there is no implicit
multiplication), and so on.

What the grammar means:

- `+` and `-` (binary) have the lowest precedence and associate to the left:
  `10 - 4 - 3` is `(10 - 4) - 3`.
- `*`, `/` and `%` come next and associate to the left: `100 / 10 / 5` is
  `(100 / 10) / 5`.
- Unary `-` and `+` come next and may be repeated: `--3` is 3, `2 - -3` is 5.
- `^` (power) binds tighter than unary minus on its left and associates to
  the right: `-2 ^ 2` is `-(2 ^ 2)`, and `2 ^ 3 ^ 2` is `2 ^ (3 ^ 2)`. Its
  right operand may carry a sign: `2 ^ -1` is 0.5. The right operand is a
  whole `unary`, so `2 ^ -2 ^ 2` is `2 ^ (-(2 ^ 2))`, which is 0.0625.
- A name whose next token is `(` is a function call (whitespace between the
  two tokens does not matter: `sqrt (4)` is a call); any other name is a
  variable.

### Evaluation

X3. **Syntax first.** The whole expression is parsed before anything is
evaluated: a malformed expression raises `ExprSyntaxError` even if it also
contains an unknown name or a division by zero.

X4. **Numbers.** All arithmetic is done with floats: number tokens and
variable values are converted with `float()`, and the result is always a
float (`evaluate("1 + 2")` is `3.0`).

X5. **Operators.** `+`, `-`, `*`, `/` are Python's float operations (`/` is
true division). `%` is Python's `%` on floats (the result has the sign of the
right operand: `-7 % 3` is 2). `^` is Python's `**` on floats.

X6. **Variables.** A variable is looked up in `variables`. Two constants are
predefined: `pi` (`math.pi`) and `e` (`math.e`); an entry of `variables` with
the same name takes precedence. A variable that is neither in `variables`
nor a constant raises `ExprNameError`.

X7. **Functions.** Functions and variables have separate name spaces: a
variable may be called `min`, and it does not hide the function.

| Function | Arguments | Result |
|---|---|---|
| `sqrt(x)` | exactly 1 | square root; `ExprError` if `x < 0` |
| `abs(x)` | exactly 1 | absolute value |
| `floor(x)` | exactly 1 | largest whole number `<= x`, as a float |
| `ceil(x)` | exactly 1 | smallest whole number `>= x`, as a float |
| `min(a, ...)` | 1 or more | smallest argument |
| `max(a, ...)` | 1 or more | largest argument |

A call of any other function name raises `ExprNameError`. A call of a known
function with a wrong number of arguments (`sqrt()`, `sqrt(1, 2)`, `min()`)
raises `ExprError`.

X8. **Arithmetic errors.**

- `ZeroDivisionError` (the built-in exception): `/` or `%` with a right
  operand of zero, and zero raised to a negative power.
- `ExprError`: a power whose result is not a real number (a negative base
  with a non-integer exponent, such as `(-8) ^ 0.5`), and a power that is
  too large for a float (Python's `OverflowError`).

X9. If an expression contains several errors of X6–X8, which one is raised
is free. Wherever this specification says `ExprError`, raising the class
itself or one of its subclasses is correct.

### Examples

```python
>>> from toolkit.calc.expr import evaluate
>>> evaluate("1 + 2"), evaluate("2 + 3 * 4"), evaluate("(2 + 3) * 4")
(3.0, 14.0, 20.0)
>>> evaluate("10 - 4 - 3"), evaluate("100 / 10 / 5"), evaluate("7 % 3"), evaluate("-7 % 3")
(3.0, 2.0, 1.0, 2.0)
>>> evaluate("-2 ^ 2"), evaluate("2 ^ 3 ^ 2"), evaluate("2 ^ -1"), evaluate("--3"), evaluate("2 - -3")
(-4.0, 512.0, 0.5, 3.0, 5.0)
>>> evaluate(".5 + 1."), evaluate(" 2\t*\n( 3 + 4 ) ")
(1.5, 14.0)
>>> evaluate("2 * x + rate", {"x": 3, "rate": 0.5})
6.5
>>> evaluate("max(1, 2 * 3, sqrt(16)) + abs(-2) + floor(2.7) + ceil(2.1) + min(4, 9)")
17.0
>>> evaluate("min + 1", {"min": 3}), evaluate("e", {"e": 5}), round(evaluate("2 * pi"), 4)
(4.0, 5.0, 6.2832)
```

Raised errors, for example:

- `ExprSyntaxError`: `evaluate("")`, `evaluate("1 +")`, `evaluate("(1 + 2")`,
  `evaluate("1 + 2)")`, `evaluate("2 x")`, `evaluate("3 $ 4")`,
  `evaluate("1 2")`, `evaluate("unknown + (")` (X3)
- `ExprNameError`: `evaluate("x + 1")`, `evaluate("cube(2)")`
- `ExprError`: `evaluate("sqrt(-1)")`, `evaluate("sqrt(1, 2)")`,
  `evaluate("(-8) ^ 0.5")`
- `ZeroDivisionError`: `evaluate("1 / 0")`, `evaluate("5 % 0")`,
  `evaluate("0 ^ -1")`
