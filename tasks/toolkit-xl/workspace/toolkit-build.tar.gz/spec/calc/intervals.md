# toolkit.calc.intervals — closed integer intervals

File: `toolkit/calc/intervals.py`. Public names: `merge_intervals`,
`intersect_intervals`, `subtract_intervals`, `count_points`. The global rules
of `spec/README.md` apply.

## Terms

An **interval** is a pair `(lo, hi)` of integers, given as a tuple or as a
list of two elements, with `lo <= hi`. It stands for the set of all integers
`x` with `lo <= x <= hi`; both ends belong to it, so `(3, 3)` holds exactly
one integer.

An **interval list** is a list or tuple of intervals, in any order, possibly
overlapping. It stands for the union of its intervals. The empty list stands
for the empty set.

The **normalised form** of a set of integers is the one list of intervals
that

- contains only tuples,
- is sorted in ascending order of `lo`, and
- has no two intervals that overlap or are adjacent: for consecutive
  intervals `(lo1, hi1)`, `(lo2, hi2)` it holds that `lo2 > hi1 + 1`.

Note the last point: because the intervals hold integers, `(1, 2)` and
`(3, 4)` are adjacent and together form `(1, 4)`; `(1, 2)` and `(4, 5)` are
not adjacent (3 is missing) and stay separate.

## Rules for all functions

V1. `ValueError` if any interval of any argument has `lo > hi`.

V2. Arguments may be any interval lists (unsorted, overlapping, lists or
tuples). Every result that is a list is a new list in normalised form.

## merge_intervals(intervals)

Returns the normalised form of the set that `intervals` stands for.

## intersect_intervals(a, b)

Returns the normalised form of the set of integers that are in `a` and in
`b`.

## subtract_intervals(a, b)

Returns the normalised form of the set of integers that are in `a` but not
in `b`.

## count_points(intervals)

Returns the number of distinct integers in the set that `intervals` stands
for, as an `int`. Integers covered by several intervals count once.

## Examples

```python
>>> from toolkit.calc.intervals import merge_intervals, intersect_intervals, subtract_intervals, count_points
>>> merge_intervals([(8, 9), [1, 2], (3, 4), (6, 6), (1, 1)])
[(1, 4), (6, 6), (8, 9)]
>>> intersect_intervals([(1, 5), (8, 12)], [(4, 9)])
[(4, 5), (8, 9)]
>>> intersect_intervals([(1, 3)], [(3, 6)])
[(3, 3)]
>>> subtract_intervals([(1, 10)], [(4, 6)])
[(1, 3), (7, 10)]
>>> subtract_intervals([(1, 5)], [(5, 8)])
[(1, 4)]
>>> count_points([(1, 3), (2, 5), (10, 10)])
6
>>> merge_intervals([])
[]
```

Raised errors, for example: `merge_intervals([(5, 1)])` and
`subtract_intervals([(1, 2)], [(9, 3)])` raise `ValueError`.
