# toolkit.data.jsonpath — a small JSONPath subset

File: `toolkit/data/jsonpath.py`. Public names: `parse_path`, `find_all`,
`find_first`, `JSONPathError`. The global rules of `spec/README.md` apply.

`JSONPathError` is a subclass of `ValueError`, defined in this module.

## Path syntax

J1. A path is `$` followed by zero or more steps, with nothing else before,
between or after them:

| Step | Written as | Meaning |
|---|---|---|
| child by name | `.name` | `name` matches `[A-Za-z_][A-Za-z0-9_]*` |
| child by quoted name | `['text']` or `["text"]` | `text` is any sequence of characters (possibly empty) that does not contain the quote character used; no escapes |
| index | `[N]` | `N` matches `-?[0-9]+` |
| wildcard | `.*` or `[*]` | all children |

J2. Anything else raises `JSONPathError`. In particular: the empty string, a
path that does not start with `$`, a `.` that is not followed by a name or
by `*`, `..`, an unclosed `[`, `[]`, a bracket whose content is not one of
the three forms above (`[abc]`, `[1.5]`, `[+1]`, `[ 0 ]`), a quoted name
whose closing quote is not immediately followed by `]`, and any whitespace
or other character outside a quoted name.

## parse_path(path)

Returns the steps of the path as a list of 2-tuples, in order:

- `("key", name)` for a child step (either form); `name` is a `str`.
- `("index", n)` for an index step; `n` is an `int`.
- `("wildcard", None)` for a wildcard step (either form).

Raises `JSONPathError` for a malformed path (J2).

```python
>>> from toolkit.data.jsonpath import parse_path, find_all, find_first
>>> parse_path("$")
[]
>>> parse_path("$.store.books[0]['first name'][*].*[-1]")
[('key', 'store'), ('key', 'books'), ('index', 0), ('key', 'first name'), ('wildcard', None), ('wildcard', None), ('index', -1)]
>>> parse_path('$["a]b"]')
[('key', 'a]b')]
```

## find_all(data, path)

Returns a list of the values in `data` that `path` matches. `data` is a
structure of dicts, lists and other values (as produced by `json.loads`).

E1. Evaluation starts with the list of current values `[data]`. Each step
replaces it by the list of the results that the step produces for each
current value, in order (results of an earlier value come before results of
a later value):

- **child** `name`: if the value is a `dict` and has the key `name`, the
  value stored under it; otherwise nothing.
- **index** `n`: if the value is a `list` and `-len(value) <= n < len(value)`,
  the element `value[n]` (negative indexes count from the end); otherwise
  nothing. A dict, a string or a tuple never matches an index step.
- **wildcard**: if the value is a `dict`, all its values in the dict's own
  order; if it is a `list`, all its elements in order; otherwise nothing.

E2. The result is the final list of current values. No match is not an
error: the result is `[]`. The path `$` gives `[data]`. The values in the
result are the objects found in `data`, not copies. `JSONPathError` is
raised for a malformed path, whatever `data` is.

```python
>>> doc = {"store": {"books": [{"title": "A", "price": 5}, {"title": "B"}], "open": None}}
>>> find_all(doc, "$.store.books[*].title")
['A', 'B']
>>> find_all(doc, "$.store.books[*].price")
[5]
>>> find_all(doc, "$.store.books[-1]")
[{'title': 'B'}]
>>> find_all(doc, "$.store.books[2]")
[]
>>> find_all(doc, "$.store.*")
[[{'title': 'A', 'price': 5}, {'title': 'B'}], None]
```

## find_first(data, path, default=None)

Returns the first element of `find_all(data, path)`, or `default` if that
list is empty. A match whose value is `None` is a match: it is returned, not
the default.

```python
>>> find_first(doc, "$.store.books[0].title")
'A'
>>> find_first(doc, "$.store.owner", default="nobody")
'nobody'
>>> find_first(doc, "$.store.open", default="unknown") is None
True
```
