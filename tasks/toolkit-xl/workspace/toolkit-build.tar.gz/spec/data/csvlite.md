# toolkit.data.csvlite — CSV parsing and formatting

File: `toolkit/data/csvlite.py`. Public names: `parse_csv`, `format_csv`,
`parse_records`, `CSVError`. The global rules of `spec/README.md` apply.

`CSVError` is a subclass of `ValueError`, defined in this module.

## The delimiter

V1. All three functions take `delimiter=","`. It must be a string of exactly
one character and must not be `"`, `"\n"` or `"\r"`; otherwise `ValueError`
is raised, before the text or the rows are looked at.

## parse_csv(text, delimiter=",")

Returns a list of rows; each row is a list of strings (the fields).

A **line terminator** is `"\r\n"` or `"\n"`. A `"\r"` that is not followed
by `"\n"` is an ordinary character.

C1. **Records.** The text is a sequence of records. Each record ends at a
line terminator or at the end of the text. The empty text has no records
(`[]`). A line terminator at the very end of the text ends the last record
and does not start another one.

C2. **Fields.** A record consists of one or more fields separated by the
delimiter. An empty line is therefore a record with one empty field (`[""]`),
and a delimiter at the end of a record is followed by one more, empty, field.

C3. **Unquoted field.** A field whose first character is not `"` (or that is
empty) runs up to the next delimiter, the next line terminator or the end of
the text. Nothing is trimmed. A `"` inside such a field is an ordinary
character.

C4. **Quoted field.** A field whose first character is `"` runs up to its
closing quote. The characters after the opening quote are read from left to
right: a `"` that is immediately followed by another `"` forms a pair, and
the pair stands for one `"`; a `"` that is not followed by another `"` is the
closing quote; every other character, including the delimiter, `"\n"` and
`"\r"`, is taken as it is. So `"say ""hi"""` is the field `say "hi"`.

C5. **Errors.** `CSVError` if the text ends before the closing quote of a
quoted field. `CSVError` if the closing quote is followed by anything other
than a delimiter, a line terminator or the end of the text.

C6. Records may have different numbers of fields.

```python
>>> from toolkit.data.csvlite import parse_csv, format_csv, parse_records
>>> parse_csv("a,b,c\n1,2,3\n")
[['a', 'b', 'c'], ['1', '2', '3']]
>>> parse_csv('x,"a,b","say ""hi""",\r\n\nlast')
[['x', 'a,b', 'say "hi"', ''], [''], ['last']]
>>> parse_csv('"two\nlines", pad ,5" tall')
[['two\nlines', ' pad ', '5" tall']]
>>> parse_csv("")
[]
>>> parse_csv("\n")
[['']]
>>> parse_csv("a;b", delimiter=";")
[['a', 'b']]
```

Raised errors, for example: `parse_csv('"abc')` and `parse_csv('"a"b,c')`
raise `CSVError`; `parse_csv("a", delimiter="::")` raises `ValueError`.

## format_csv(rows, delimiter=",")

Returns CSV text for `rows`, a list or tuple of rows; each row is a list or
tuple of values.

M1. **Field text.** `None` becomes `""`; every other value `v` becomes
`str(v)`.

M2. **Quoting.** A field text is quoted if and only if it contains the
delimiter, a `"`, a `"\n"` or a `"\r"`. Quoting means: every `"` is doubled
and the result is put between two `"`. Other field texts (the empty string
too) are written as they are.

M3. **Records.** The fields of a row are joined with the delimiter, and every
record, the last one included, is followed by `"\n"`. No rows give `""`; a
row without fields gives an empty line.

```python
>>> format_csv([["name", "note"], ["Ann", 'said "hi", left'], [1, None]])
'name,note\nAnn,"said ""hi"", left"\n1,\n'
>>> format_csv([])
''
```

For rows that contain only strings and have at least one field each,
`parse_csv(format_csv(rows)) == rows`.

## parse_records(text, delimiter=",")

Returns a list of dicts, using the first record as the header.

H1. `rows = parse_csv(text, delimiter)`; its errors are raised unchanged.
No rows give `[]`.

H2. The first row holds the column names. `CSVError` if a name occurs more
than once.

H3. Every further row gives one dict that maps each column name to the field
at the same position. A row with fewer fields than there are column names
gets `""` for the missing ones. `CSVError` if a row has more fields than
there are column names.

```python
>>> parse_records("name,age\nann,3\nbob\n")
[{'name': 'ann', 'age': '3'}, {'name': 'bob', 'age': ''}]
>>> parse_records("name,age\n")
[]
```
