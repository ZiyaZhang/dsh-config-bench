# toolkit.data.diff — line diff

File: `toolkit/data/diff.py`. Public names: `diff_lines`, `format_diff`,
`diff_stats`. The global rules of `spec/README.md` apply.

All three functions take two texts `a` (the old text) and `b` (the new
text). The lines of a text are `text.splitlines()`: the line ends are not
part of the lines, the empty text has no lines, and a line end at the very
end of the text does not add an empty line. Lines are compared with `==`
(case and whitespace matter).

## diff_lines(a, b)

Returns a list of 2-tuples `(tag, line)`. The tag is `" "` for a line that
is in both texts, `"-"` for a line that is only in `a`, and `"+"` for a line
that is only in `b`.

D1. Let `A = a.splitlines()` and `B = b.splitlines()`, and let `L(i, j)` be
the length of the longest common subsequence of `A[i:]` and `B[j:]`.

D2. The result is produced by this procedure, which every implementation
must reproduce exactly (it fixes which of several equally short diffs is
returned). Start with `i = 0` and `j = 0` and repeat until `i == len(A)` and
`j == len(B)`:

1. If `i < len(A)` and `j < len(B)` and `A[i] == B[j]`: append
   `(" ", A[i])`; add 1 to `i` and to `j`.
2. Otherwise, if `j == len(B)`, or if `i < len(A)` and
   `L(i + 1, j) >= L(i, j + 1)`: append `("-", A[i])`; add 1 to `i`.
3. Otherwise: append `("+", B[j])`; add 1 to `j`.

Consequences: the unchanged lines form a longest common subsequence; when
removing the old line and adding the new line are equally good, the removal
comes first.

```python
>>> from toolkit.data.diff import diff_lines, format_diff, diff_stats
>>> diff_lines("one\ntwo\nthree\n", "one\n2\nthree")
[(' ', 'one'), ('-', 'two'), ('+', '2'), (' ', 'three')]
>>> diff_lines("a\nb", "b\na")
[('-', 'a'), (' ', 'b'), ('+', 'a')]
>>> diff_lines("b\nc", "a\nb\nc")
[('+', 'a'), (' ', 'b'), (' ', 'c')]
>>> diff_lines("", "")
[]
```

In the second example `L(1, 0)` and `L(0, 1)` are both 1, so rule 2 removes
`a` first. In the third example `L(1, 0)` is 1 and `L(0, 1)` is 2, so rule 3
adds `a` first.

## format_diff(a, b, context=None)

Returns the diff as one string.

F1. `ValueError` if `context` is not `None` and `context < 0`.

F2. Let `entries = diff_lines(a, b)`. An entry is written as the line
`tag + " " + line` — for example `"  same"`, `"- old"`, `"+ new"`.

F3. If `context` is `None`, every entry is shown.

F4. If `context` is an integer `c`: entries with the tag `"-"` or `"+"`
(changes) are always shown. An entry with the tag `" "` at index `k` of
`entries` is shown if some change has an index `m` with `abs(k - m) <= c`;
otherwise it is hidden. Every maximal run of consecutive hidden entries is
replaced by one line that consists of exactly three dots: `...`

F5. The lines are joined with `"\n"`; there is no trailing newline. Without
entries the result is `""`.

```python
>>> old = "1\n2\n3\n4\n5\n6\n7"
>>> new = "1\n2\n3\nX\n5\n6\n7"
>>> print(format_diff("one\ntwo", "one\n2"))
  one
- two
+ 2
>>> format_diff(old, new, context=1).split("\n")
['...', '  3', '- 4', '+ X', '  5', '...']
>>> format_diff(old, new, context=0).split("\n")
['...', '- 4', '+ X', '...']
>>> format_diff(old, new, context=3) == format_diff(old, new)
True
>>> format_diff("same\ntext", "same\ntext", context=3)
'...'
```

Printed, the result for `context=1` is:

```
...
  3
- 4
+ X
  5
...
```

The eight entries have the indexes 0–7 and the changes are at 3 and 4. With
`context=1` the unchanged entries 2 and 5 are shown; the entries 0–1 and 6–7
are hidden and each run becomes one `...` line. With `context=3` every
unchanged entry is within 3 of a change, so nothing is hidden. In the last
example there is no change at all, so both entries are hidden and form one
run.

## diff_stats(a, b)

Returns a dict with exactly three keys, counting the entries of
`diff_lines(a, b)` by tag: `"added"` (tag `"+"`), `"removed"` (tag `"-"`)
and `"unchanged"` (tag `" "`).

```python
>>> diff_stats("one\ntwo\nthree", "one\n2\nthree\nfour") == {"added": 2, "removed": 1, "unchanged": 2}
True
```
