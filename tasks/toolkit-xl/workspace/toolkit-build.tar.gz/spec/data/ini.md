# toolkit.data.ini — INI parsing with typed values

File: `toolkit/data/ini.py`. Public names: `parse_ini`, `parse_value`,
`INIError`. The global rules of `spec/README.md` apply.

`INIError` is a subclass of `ValueError`, defined in this module.

## parse_ini(text)

Returns a dict that maps each section name to a dict of that section's keys
and typed values.

N1. **Lines.** The text is split with `text.split("\n")` and every line is
stripped with `str.strip()` (so `"\r\n"` line ends work too). Each stripped
line is handled by the first rule that applies:

1. The line is empty: ignored.
2. The line starts with `#` or `;`: a comment, ignored.
3. The line starts with `[`: a **section header**. It must end with `]`,
   otherwise `INIError`. The section name is the text between the first and
   the last character of the line, stripped; if that is empty, `INIError`.
   This section becomes the current section. If the name is new, the section
   is added to the result with an empty dict; if it was seen before, its
   existing dict is used again.
4. Any other line is a **key/value line**. It must contain `=`, otherwise
   `INIError`. The key is the text before the first `=`, stripped; an empty
   key is an `INIError`. The value is `parse_value(text after the first "=")`.
   The pair is stored in the current section; assigning a key again replaces
   its value.

N2. **Keys before the first section header** belong to the section named
`""` (empty string). That section exists in the result only if such a key
occurs.

N3. Section names and keys are case-sensitive and are not converted.

N4. **Order.** The sections appear in the result in the order of their first
appearance in the text, and the keys of a section in the order of their
first assignment.

```python
>>> from toolkit.data.ini import parse_ini, parse_value
>>> parse_ini("name = demo\n\n[server]\nhost = example.org\nport = 8080\n; note\n[empty]\n[server]\ndebug = off\n")
{'': {'name': 'demo'}, 'server': {'host': 'example.org', 'port': 8080, 'debug': False}, 'empty': {}}
>>> parse_ini("")
{}
```

Raised errors, for example: `parse_ini("[server")`, `parse_ini("[ ]")`,
`parse_ini("just words")` and `parse_ini("= 5")` raise `INIError`.

## parse_value(raw)

Converts the text to the right of `=` into a typed value.

A1. Let `s = raw.strip()`.

A2. **Quoted value.** If `s` starts with `"`: the value ends at the next `"`
after the first character; if there is none, `INIError`. The result is the
text between the two quotes, exactly as written, always a `str` (no type
conversion, no comment handling inside the quotes). The text after the
closing quote, stripped, must be empty or start with `#` or `;` (a comment);
otherwise `INIError`.

A3. **Inline comment** (unquoted values only). Find the first position `p`
with `s[p]` being `#` or `;` and either `p == 0` or `s[p - 1]` a whitespace
character. If there is one, `s` becomes `s[:p]` stripped. A `#` or `;` that
directly follows a non-whitespace character does not start a comment.

A4. **Type conversion** (unquoted values only). The first rule that applies
gives the result:

1. `s` is empty: `""`.
2. `s.lower()` is `true`, `yes` or `on`: `True`.
3. `s.lower()` is `false`, `no` or `off`: `False`.
4. `s.lower()` is `null` or `none`: `None`.
5. `s` fully matches the regular expression `[+-]?[0-9]+`: `int(s)`.
6. `s` fully matches the regular expression `[+-]?([0-9]+\.[0-9]*|\.[0-9]+)`
   (digits, a dot and optional digits; or a dot followed by digits):
   `float(s)`.
7. Anything else: `s` itself, a `str`.

Exponent notation, hexadecimal notation and digit separators are therefore
not numbers: `1e5`, `0x10` and `1_000` stay strings.

```python
>>> [parse_value(v) for v in [" 42 ", "-7", "+3.50", ".5", "1e5", "0x10"]]
[42, -7, 3.5, 0.5, '1e5', '0x10']
>>> [parse_value(v) for v in ["Yes", "OFF", "None", "", "hello world"]]
[True, False, None, '', 'hello world']
>>> [parse_value(v) for v in ['"42"', '" padded "  ; note', '"a # b"']]
['42', ' padded ', 'a # b']
>>> [parse_value(v) for v in ["8080 # port", "a#b", "; only a comment", "x ;y # z"]]
[8080, 'a#b', '', 'x']
```

Raised errors, for example: `parse_value('"open')` and
`parse_value('"a" b')` raise `INIError`.
