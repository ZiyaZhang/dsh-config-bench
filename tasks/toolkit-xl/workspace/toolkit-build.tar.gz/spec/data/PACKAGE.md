# toolkit.data — package facade

File: `toolkit/data/__init__.py`. The global rules of `spec/README.md` apply.

## Re-exports

The facade imports its four modules and re-exports these names (the very
same objects), so that for example `toolkit.data.parse_csv` is
`toolkit.data.csvlite.parse_csv`:

| From module | Names |
|---|---|
| `toolkit.data.csvlite` | `parse_csv`, `format_csv`, `parse_records`, `CSVError` |
| `toolkit.data.ini` | `parse_ini`, `parse_value`, `INIError` |
| `toolkit.data.jsonpath` | `parse_path`, `find_all`, `find_first`, `JSONPathError` |
| `toolkit.data.diff` | `diff_lines`, `format_diff`, `diff_stats` |

`__all__` lists these fourteen names and `query` (the order is free).

## query(text, path, fmt="csv")

Parses a document and returns the values that a JSONPath matches in it, as
a list.

Q1. The document is built from `text` according to `fmt`:

- `"csv"`: `parse_records(text)` with the default delimiter — a list of
  dicts whose values are strings.
- `"ini"`: `parse_ini(text)` — a dict of sections.
- any other value of `fmt`: `ValueError`.

Q2. The result is `find_all(document, path)`.

Q3. Errors of the modules are raised unchanged: `CSVError`, `INIError`,
`JSONPathError`.

```python
>>> from toolkit.data import query
>>> query("name,age\nann,3\nbob,5\n", "$[*].name")
['ann', 'bob']
>>> query("name,age\nann,3\nbob,5\n", "$[-1]")
[{'name': 'bob', 'age': '5'}]
>>> query("[server]\nport = 8080\ndebug = no\n", "$.server.*", fmt="ini")
[8080, False]
>>> query("[server]\nport = 8080\n", "$.client.port", "ini")
[]
```
