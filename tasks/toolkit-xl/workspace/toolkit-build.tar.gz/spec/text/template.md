# toolkit.text.template — mini template language

File: `toolkit/text/template.py`. Public names: `render_template`,
`template_variables`, `TemplateError`. The global rules of `spec/README.md`
apply.

`TemplateError` is a subclass of `ValueError`, defined in this module.

## Template syntax

P1. **Scanning.** A template is read from left to right, starting at
position 0. At each position, the first rule that applies is used:

1. The text at this position starts with the three characters `\{{`
   (backslash, brace, brace): the two characters `{{` are output and the
   position moves on by 3. This is how a literal `{{` is written.
2. The text at this position starts with `{{`: a **placeholder** begins. Its
   **body** is everything between this `{{` and the next `}}` that follows
   it. If there is no such `}}`, the template is malformed (`TemplateError`).
   The position moves to just after that `}}`.
3. Otherwise one character is copied to the output and the position moves on
   by 1.

So a `}}` outside a placeholder, a single `{`, and a backslash that is not
followed by `{{` are ordinary text, and the empty template gives `""`.

P2. **Body.** The body is split at every `|`; each part is stripped with
`str.strip()`.

- The first part is the **variable path**. It must fully match
  `[A-Za-z_][A-Za-z0-9_]*(\.[A-Za-z_][A-Za-z0-9_]*)*` — one or more names
  joined by dots. Otherwise: `TemplateError`.
- Every further part is a **filter**. It must be exactly one of `upper`,
  `lower`, `title`, `trim`, `length`, or fully match the regular expression
  `default\s*:\s*"([^"]*)"`, whose group is the default text. Otherwise:
  `TemplateError`. The default text is used exactly as written between the
  quotes (it may be empty and may contain spaces; it cannot contain `"`,
  `|` or `}}`, which follows from P1 and from the splitting at `|`).

## render_template(template, context)

Returns the template with every placeholder replaced. `context` is a dict.

R1. **Syntax first.** The whole template is checked before any variable is
looked up: if any placeholder is malformed, `TemplateError` is raised, even
when a variable is missing as well.

R2. **Lookup.** The names of the variable path are looked up one after
another, starting with `context` as the current value: if the current value
is a `dict` that has the name as a key, the value stored under that key
becomes the current value; otherwise the variable is **missing**. A value of
`None` is found, not missing.

R3. **Text of a value**: `""` for `None`, otherwise `str(value)`.

R4. **Filters** are applied from left to right to the looked-up value:

| Filter | Result |
|---|---|
| `default:"TEXT"` | `TEXT` if the value is missing or `None`; otherwise the value unchanged |
| `upper` | the text of the value, upper-cased with `str.upper()` |
| `lower` | the text of the value, lower-cased with `str.lower()` |
| `title` | the text of the value after `str.title()` |
| `trim` | the text of the value after `str.strip()` |
| `length` | `len(value)` if the value is a `str`, `list`, `tuple` or `dict`; otherwise the length of the text of the value. The result is an `int`. |

A missing value stays missing through every filter except `default`.

R5. **Output.** If the value is still missing after the last filter,
`KeyError` is raised. Otherwise the placeholder is replaced by the text of
the value (R3).

```python
>>> from toolkit.text.template import render_template, template_variables
>>> render_template("Hello {{ name }}!", {"name": "World"})
'Hello World!'
>>> render_template("{{user.name|trim|upper}} has {{ items | length }} items", {"user": {"name": " ann "}, "items": [1, 2, 3]})
'ANN has 3 items'
>>> render_template('{{ nick | default:"nobody" }} / {{ age | default:"?" }}', {"age": None})
'nobody / ?'
>>> render_template('{{ nick | upper | default:"n/a" }} {{ nick | default:"n/a" | upper }}', {})
'n/a N/A'
>>> render_template(r"\{{ raw }} and {{ x }} }}", {"x": 1})
'{{ raw }} and 1 }}'
```

In the fourth example `upper` leaves the missing value missing, so the
default text is output unchanged; in the second placeholder the default text
is produced first and then upper-cased.

Raised errors, for example:

- `render_template("{{ name", {})` — `TemplateError` (no closing `}}`)
- `render_template("{{ 1abc }}", {})` and `render_template("{{ }}", {})` — `TemplateError` (invalid path)
- `render_template("{{ a | shout }}", {"a": 1})` — `TemplateError` (unknown filter)
- `render_template("{{ a.b }}", {"a": 5})` — `KeyError` (missing: `5` is not a dict)
- `render_template("{{ a }} {{ b | shout }}", {})` — `TemplateError` (R1)

## template_variables(template)

Returns a list of the variable paths of all placeholders, as written in the
template (complete dotted paths), in order of first appearance and without
duplicates. The template is checked as in `render_template`; a malformed
template raises `TemplateError`. Text written with `\{{` is not a
placeholder.

```python
>>> template_variables("{{a}} {{ b.c | upper }} {{a|lower}} \\{{ d }}")
['a', 'b.c']
>>> template_variables("no placeholders")
[]
```
