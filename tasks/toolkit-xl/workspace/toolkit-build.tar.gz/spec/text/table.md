# toolkit.text.table — plain-text tables

File: `toolkit/text/table.py`. Public name: `render_table`.
The global rules of `spec/README.md` apply.

## render_table(rows, headers=None, align="", max_width=None)

Returns the table as one string.

- `rows`: a list or tuple of rows; each row is a list or tuple of cell values.
- `headers`: `None`, or a list or tuple of header cell values.
- `align`: a string made of the characters `l`, `r` and `c`.
- `max_width`: `None` or an integer.

T1. **Validation**, done first, even for a table without columns:
`ValueError` if `align` contains any character other than `l`, `r`, `c`;
`ValueError` if `max_width` is not `None` and `max_width < 4`.

T2. **Cell text.** `None` becomes `""`; every other value `v` becomes
`str(v)`. Header cells are converted in the same way.

T3. **Truncation.** If `max_width` is not `None`, every cell text (header
cells included) that is longer than `max_width` is replaced by its first
`max_width - 3` characters followed by `...`. A text of exactly `max_width`
characters is not changed.

T4. **Columns.** The number of columns `n` is the largest number of cells in
any row, counting the header row if `headers` is not `None`; `n` is 0 when
there is no row at all or when no row has a cell. If `n` is 0 the result is
`""`. Every row with fewer than `n` cells (the header row too) is extended
on the right with empty cells (`""`).

T5. **Widths.** The width of a column is the largest `len()` of the cell
texts in that column after T3, header cell included. A width of 0 is
possible and needs no special treatment.

T6. **Alignment.** Character `j` of `align` belongs to column `j` (counting
from 0). Columns for which `align` has no character are left-aligned;
characters beyond the last column are ignored (but still validated by T1).
A cell text is padded with spaces to the width of its column:

- `l`: text, then the padding.
- `r`: the padding, then text.
- `c`: with `p` padding spaces in total, `p // 2` spaces go to the left and
  the remaining `p - p // 2` to the right (an odd space goes to the right).

Header cells are aligned like the other cells of their column.

T7. **Lines.** A row becomes `"| " + " | ".join(padded_cells) + " |"`.
The separator line is `"|" + "|".join(dashes) + "|"`, where `dashes` holds,
for each column, `"-"` repeated `width + 2` times.

T8. **Result.** If `headers` is not `None`: the header line, the separator
line, then one line per row. If `headers` is `None`: one line per row and no
separator line. The lines are joined with `"\n"`; there is no trailing
newline.

```python
>>> from toolkit.text.table import render_table
>>> print(render_table([["apple", 3], ["kiwi", 12]], headers=["name", "qty"], align="lr"))
| name  | qty |
|-------|-----|
| apple |   3 |
| kiwi  |  12 |
>>> print(render_table([["ab", "x"], ["abcde", None]], align="c"))
|  ab   | x |
| abcde |   |
>>> print(render_table([["a"], ["b", "c", "d"]], headers=["one", "two"]))
| one | two |   |
|-----|-----|---|
| a   |     |   |
| b   | c   | d |
>>> print(render_table([["abcdefghij", "abcdef"]], max_width=6))
| abc... | abcdef |
>>> render_table([], headers=[])
''
```
