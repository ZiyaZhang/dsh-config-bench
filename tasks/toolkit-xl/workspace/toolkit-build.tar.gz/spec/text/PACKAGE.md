# toolkit.text — package facade

File: `toolkit/text/__init__.py`. The global rules of `spec/README.md` apply.

## Re-exports

The facade imports its four modules and re-exports these names (the very
same objects), so that for example `toolkit.text.slugify` is
`toolkit.text.slug.slugify`:

| From module | Names |
|---|---|
| `toolkit.text.wrap` | `wrap_lines`, `fill`, `shorten` |
| `toolkit.text.table` | `render_table` |
| `toolkit.text.slug` | `slugify`, `unique_slug`, `slugify_all` |
| `toolkit.text.template` | `render_template`, `template_variables`, `TemplateError` |

`__all__` lists these ten names and `toc` (the order is free).

## toc(titles)

Returns a table of contents as one string. `titles` is any iterable of
strings; it is read once.

C1. The anchors are `slugify_all(titles)` (default separator), each prefixed
with `#`.

C2. The table has one row per title, in order, with three cells: the
position of the title counted from 1 (an `int`), the title exactly as given,
and the anchor.

C3. The result is
`render_table(rows, headers=["#", "Title", "Anchor"], align="rll")`.
With no titles this is the header line and the separator line only.

```python
>>> from toolkit.text import toc
>>> print(toc(["Getting Started", "FAQ", "FAQ"]))
| # | Title           | Anchor           |
|---|-----------------|------------------|
| 1 | Getting Started | #getting-started |
| 2 | FAQ             | #faq             |
| 3 | FAQ             | #faq-2           |
>>> print(toc([]))
| # | Title | Anchor |
|---|-------|--------|
```
