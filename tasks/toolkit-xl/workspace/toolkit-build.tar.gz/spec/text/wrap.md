# toolkit.text.wrap — word wrapping

File: `toolkit/text/wrap.py`. Public names: `wrap_lines`, `fill`, `shorten`.
The global rules of `spec/README.md` apply.

A **word** is an item of `text.split()` (called without arguments), so words
are separated by runs of whitespace (spaces, tabs, newlines, ...), and leading
and trailing whitespace is ignored. Lengths are `len()`.

## wrap_lines(text, width=70, initial_indent="", subsequent_indent="")

Returns a list of strings: the lines of the wrapped text.

W1. **Validation**, done first, even when the text has no words:
`ValueError` if `width < 1`; `ValueError` if `len(initial_indent) >= width`
or `len(subsequent_indent) >= width`.

W2. If the text has no words (empty or only whitespace) the result is `[]`.

W3. Lines are built one after another until no words are left. The **prefix**
of the first line is `initial_indent`; the prefix of every other line is
`subsequent_indent`. Prefixes are used exactly as given. For the line being
built let `room = width - len(prefix)`.

- (a) Take the next word. If `len(word) > room`, the line is
  `prefix + word[:room]` and it is complete; `word[room:]` is put back as the
  next word. From then on that remainder is treated like any other word: it
  may be split again, and other words may follow it on its line.
- (b) Otherwise the line starts as `prefix + word`. While there is a next
  word and `len(line) + 1 + len(next_word) <= width`, one space and that word
  are appended. When the next word does not fit — however long it is — the
  line is complete, and that word becomes the first word of the following
  line, where (a) or (b) is applied to it.

So a word is split only when it is the first word of a line, lines never
exceed `width`, and words on one line are separated by exactly one space.

```python
>>> from toolkit.text.wrap import wrap_lines, fill, shorten
>>> wrap_lines("The quick brown fox jumps over the lazy dog", 10)
['The quick', 'brown fox', 'jumps over', 'the lazy', 'dog']
>>> wrap_lines("one two three four", 9, "* ", "  ")
['* one two', '  three', '  four']
>>> wrap_lines("abcdefghijklmnop qr", 5)
['abcde', 'fghij', 'klmno', 'p qr']
>>> wrap_lines("aa bbbbbbbb cc", 5)
['aa', 'bbbbb', 'bbb', 'cc']
>>> wrap_lines("   ", 10)
[]
```

In the fourth example `bbbbbbbb` does not fit after `aa`, so it starts the
next line and is split there; nothing of it is placed after `aa`.

## fill(text, width=70, initial_indent="", subsequent_indent="")

Returns one string: the text wrapped paragraph by paragraph.

F1. The validation of W1 is done first.

F2. `text.split("\n")` gives the input lines. An input line is **blank** if
`line.strip() == ""`. A **paragraph** is a maximal run of consecutive
non-blank input lines.

F3. The words of a paragraph are the words of its lines, in order (a line
break inside a paragraph is ordinary whitespace). Each paragraph is wrapped
on its own with `wrap_lines` and the same `width`, `initial_indent` and
`subsequent_indent`; so `initial_indent` starts the first line of *every*
paragraph.

F4. The lines of a paragraph are joined with `"\n"`. Paragraphs are joined
with `"\n\n"`, however many blank lines separated them in the input. There is
no trailing newline. A text without paragraphs gives `""`.

```python
>>> fill("one two three\nfour\n\n\n  \nfive six", 9, "* ", "  ")
'* one two\n  three\n  four\n\n* five\n  six'
>>> fill("\n \n", 20)
''
```

## shorten(text, width, placeholder="...")

Returns the text on one line, cut at a word boundary if it is too long.

S1. `ValueError` if `width < len(placeholder)`. This is checked first and
does not depend on the text.

S2. Let `words = text.split()` and `collapsed = " ".join(words)`. If
`len(collapsed) <= width` the result is `collapsed`.

S3. Otherwise let `k` be the largest integer with `0 <= k <= len(words)` and
`len(" ".join(words[:k])) + len(placeholder) <= width`. The result is
`" ".join(words[:k]) + placeholder`. No space is inserted before the
placeholder, and for `k = 0` the result is the placeholder alone.

```python
>>> shorten("  The   quick brown\nfox ", 30)
'The quick brown fox'
>>> shorten("The quick brown fox", 12)
'The quick...'
>>> shorten("The quick brown fox", 11)
'The...'
>>> shorten("Supercalifragilistic word", 8)
'...'
>>> shorten("The quick brown fox", 12, placeholder=" [more]")
'The [more]'
```
