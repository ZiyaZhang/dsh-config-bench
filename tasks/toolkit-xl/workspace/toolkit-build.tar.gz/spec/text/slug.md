# toolkit.text.slug — URL slugs

File: `toolkit/text/slug.py`. Public names: `slugify`, `unique_slug`,
`slugify_all`. The global rules of `spec/README.md` apply.

## slugify(text, separator="-", max_length=None)

Returns a slug: a string made only of the characters `a`–`z`, `0`–`9` and
the separator.

L1. **Validation**, done first: `ValueError` if `separator` is not exactly
`"-"` or `"_"`; `ValueError` if `max_length` is not `None` and
`max_length < 1`.

L2. The slug is computed by these steps, in this order:

1. Apply `unicodedata.normalize("NFKD", text)`.
2. Delete every character `ch` for which `unicodedata.combining(ch)` is not 0
   (this removes accents: `é` becomes `e`).
3. Convert to lower case with `str.lower()`.
4. Delete every apostrophe: U+0027 (`'`) and U+2019 (`’`).
5. Replace every maximal run of characters that are not `a`–`z` or `0`–`9`
   by one separator. Everything else counts as such a character: spaces,
   punctuation, `-`, `_`, and letters that are still not ASCII after steps
   1–3 (for example `ß`, `ø`, Greek, CJK).
6. Remove separators from the start and the end.
7. If `max_length` is not `None` and the slug is longer than `max_length`,
   keep its first `max_length` characters and then remove separators from the
   end again.

The result may be the empty string.

```python
>>> from toolkit.text.slug import slugify, unique_slug, slugify_all
>>> slugify("  Héllo, Wörld! It's  ")
'hello-world-its'
>>> slugify("snake_case and kebab-case", separator="_")
'snake_case_and_kebab_case'
>>> slugify("The Quick Brown Fox", max_length=10)
'the-quick'
>>> slugify("Straße 42")
'stra-e-42'
>>> slugify("日本語 !!!")
''
```

In the third example the first 10 characters are `the-quick-`; the separator
at the end is then removed.

## unique_slug(text, taken, separator="-")

Returns a slug for `text` that is not in `taken`. `taken` is any object that
supports the `in` operator on strings (list, tuple, set, dict, ...); it is
not modified.

U1. `base = slugify(text, separator)` (so an invalid separator raises
`ValueError`). If `base` is `""`, `base` is `"untitled"` instead.

U2. If `base` is not in `taken`, the result is `base`.

U3. Otherwise the result is `base + separator + str(n)` for the smallest
integer `n >= 2` for which that string is not in `taken`.

```python
>>> unique_slug("Hello World", [])
'hello-world'
>>> unique_slug("Hello World", {"hello-world", "hello-world-2"})
'hello-world-3'
>>> unique_slug("Hello World", ["hello-world", "hello-world-3"])
'hello-world-2'
>>> unique_slug("???", ["untitled"], separator="_")
'untitled_2'
```

## slugify_all(texts, separator="-")

Returns a list with one slug per item of `texts` (any iterable of strings),
in the same order, without duplicates.

A1. The texts are processed in order. The slug of each text is
`unique_slug(text, earlier, separator)`, where `earlier` holds the slugs
already produced for the texts before it.

```python
>>> slugify_all(["Intro", "intro", "Intro!"])
['intro', 'intro-2', 'intro-3']
>>> slugify_all(["a", "a", "a-2"])
['a', 'a-2', 'a-2-2']
>>> slugify_all([])
[]
```

In the second example the third text has the base `a-2`, which the second
text already took, so it becomes `a-2-2`.
