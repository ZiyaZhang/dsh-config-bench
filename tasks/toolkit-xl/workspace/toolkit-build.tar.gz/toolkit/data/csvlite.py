"""CSV parsing and formatting. See spec/data/csvlite.md."""


class CSVError(ValueError):
    """Raised when CSV text is malformed; see spec/data/csvlite.md."""


def parse_csv(text, delimiter=","):
    """Parse CSV text into a list of rows; see spec/data/csvlite.md."""
    raise NotImplementedError


def format_csv(rows, delimiter=","):
    """Format rows as CSV text; see spec/data/csvlite.md."""
    raise NotImplementedError


def parse_records(text, delimiter=","):
    """Parse CSV text with a header row into a list of dicts; see spec/data/csvlite.md."""
    raise NotImplementedError
