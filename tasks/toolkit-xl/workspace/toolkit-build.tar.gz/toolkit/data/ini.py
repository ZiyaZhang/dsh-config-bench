"""INI parsing with typed values. See spec/data/ini.md."""


class INIError(ValueError):
    """Raised when INI text is malformed; see spec/data/ini.md."""


def parse_ini(text):
    """Parse INI text into a dict of sections; see spec/data/ini.md."""
    raise NotImplementedError


def parse_value(raw):
    """Convert the text right of '=' into a typed value; see spec/data/ini.md."""
    raise NotImplementedError
