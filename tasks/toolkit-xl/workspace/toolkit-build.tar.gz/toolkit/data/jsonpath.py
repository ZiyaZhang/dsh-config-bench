"""A small JSONPath subset. See spec/data/jsonpath.md."""


class JSONPathError(ValueError):
    """Raised when a path is malformed; see spec/data/jsonpath.md."""


def parse_path(path):
    """Parse a path into a list of steps; see spec/data/jsonpath.md."""
    raise NotImplementedError


def find_all(data, path):
    """Return all values of data matched by path; see spec/data/jsonpath.md."""
    raise NotImplementedError


def find_first(data, path, default=None):
    """Return the first match of path in data, or default; see spec/data/jsonpath.md."""
    raise NotImplementedError
