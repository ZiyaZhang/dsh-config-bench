"""Line diff based on the longest common subsequence. See spec/data/diff.md."""


def diff_lines(a, b):
    """Return the line diff of two texts as (tag, line) tuples; see spec/data/diff.md."""
    raise NotImplementedError


def format_diff(a, b, context=None):
    """Return the line diff of two texts as one string; see spec/data/diff.md."""
    raise NotImplementedError


def diff_stats(a, b):
    """Count added, removed and unchanged lines; see spec/data/diff.md."""
    raise NotImplementedError
