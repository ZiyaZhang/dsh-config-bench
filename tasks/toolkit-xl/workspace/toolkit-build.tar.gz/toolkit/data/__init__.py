"""Facade of the toolkit.data package. See spec/data/PACKAGE.md."""

from .csvlite import CSVError, format_csv, parse_csv, parse_records
from .diff import diff_lines, diff_stats, format_diff
from .ini import INIError, parse_ini, parse_value
from .jsonpath import JSONPathError, find_all, find_first, parse_path

__all__ = [
    "CSVError",
    "INIError",
    "JSONPathError",
    "diff_lines",
    "diff_stats",
    "find_all",
    "find_first",
    "format_csv",
    "format_diff",
    "parse_csv",
    "parse_ini",
    "parse_path",
    "parse_records",
    "parse_value",
    "query",
]


def query(text, path, fmt="csv"):
    """Parse text as CSV records or INI and return the matches of path; see spec/data/PACKAGE.md."""
    raise NotImplementedError
