"""Command-line entry point: python -m toolkit. See spec/README.md, section 4."""

import sys


def main(argv=None):
    """Run the command line and return the exit status; see spec/README.md, section 4."""
    raise NotImplementedError


if __name__ == "__main__":
    sys.exit(main())
