"""Plain-text table rendering. See spec/text/table.md."""


def render_table(rows, headers=None, align="", max_width=None):
    """Render rows as a plain-text table; see spec/text/table.md."""
    raise NotImplementedError
