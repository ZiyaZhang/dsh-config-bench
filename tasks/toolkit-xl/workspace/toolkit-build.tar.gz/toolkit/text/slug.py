"""URL slugs with de-duplication. See spec/text/slug.md."""


def slugify(text, separator="-", max_length=None):
    """Turn text into a slug; see spec/text/slug.md."""
    raise NotImplementedError


def unique_slug(text, taken, separator="-"):
    """Return a slug for text that is not in taken; see spec/text/slug.md."""
    raise NotImplementedError


def slugify_all(texts, separator="-"):
    """Slugify all texts without duplicates; see spec/text/slug.md."""
    raise NotImplementedError
