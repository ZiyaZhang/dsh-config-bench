"""Word wrapping with indentation rules. See spec/text/wrap.md."""


def wrap_lines(text, width=70, initial_indent="", subsequent_indent=""):
    """Wrap text into a list of lines; see spec/text/wrap.md."""
    raise NotImplementedError


def fill(text, width=70, initial_indent="", subsequent_indent=""):
    """Wrap text paragraph by paragraph into one string; see spec/text/wrap.md."""
    raise NotImplementedError


def shorten(text, width, placeholder="..."):
    """Collapse whitespace and cut text at a word boundary; see spec/text/wrap.md."""
    raise NotImplementedError
