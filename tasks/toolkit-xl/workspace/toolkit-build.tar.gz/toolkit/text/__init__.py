"""Facade of the toolkit.text package. See spec/text/PACKAGE.md."""

from .slug import slugify, slugify_all, unique_slug
from .table import render_table
from .template import TemplateError, render_template, template_variables
from .wrap import fill, shorten, wrap_lines

__all__ = [
    "TemplateError",
    "fill",
    "render_table",
    "render_template",
    "shorten",
    "slugify",
    "slugify_all",
    "template_variables",
    "toc",
    "unique_slug",
    "wrap_lines",
]


def toc(titles):
    """Render a table of contents for titles; see spec/text/PACKAGE.md."""
    raise NotImplementedError
