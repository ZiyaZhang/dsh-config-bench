"""Mini template language. See spec/text/template.md."""


class TemplateError(ValueError):
    """Raised when a template is malformed; see spec/text/template.md."""


def render_template(template, context):
    """Replace the placeholders of template using context; see spec/text/template.md."""
    raise NotImplementedError


def template_variables(template):
    """List the variable paths used in template; see spec/text/template.md."""
    raise NotImplementedError
