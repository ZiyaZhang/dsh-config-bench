"""toolkit: small text, data and calculation helpers. See spec/README.md."""
