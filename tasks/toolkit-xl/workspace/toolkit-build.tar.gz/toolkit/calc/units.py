"""Quantities and unit conversion. See spec/calc/units.md."""


class UnitError(ValueError):
    """Raised for bad quantities, unknown units and family mismatches; see spec/calc/units.md."""


def parse_quantity(text):
    """Parse text such as '3.5 km' into (value, unit); see spec/calc/units.md."""
    raise NotImplementedError


def unit_family(unit):
    """Return the family of a unit symbol; see spec/calc/units.md."""
    raise NotImplementedError


def convert(value, from_unit, to_unit):
    """Convert value between two units of one family; see spec/calc/units.md."""
    raise NotImplementedError


def format_number(value, precision=3):
    """Format a number without trailing zeros; see spec/calc/units.md."""
    raise NotImplementedError


def format_quantity(value, unit, precision=3):
    """Format a value with its unit; see spec/calc/units.md."""
    raise NotImplementedError


def convert_text(text, to_unit, precision=3):
    """Parse, convert and format a quantity; see spec/calc/units.md."""
    raise NotImplementedError
