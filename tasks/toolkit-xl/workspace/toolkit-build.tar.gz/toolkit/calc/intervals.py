"""Closed integer intervals. See spec/calc/intervals.md."""


def merge_intervals(intervals):
    """Return the union of the intervals in normalised form; see spec/calc/intervals.md."""
    raise NotImplementedError


def intersect_intervals(a, b):
    """Return the integers covered by both a and b; see spec/calc/intervals.md."""
    raise NotImplementedError


def subtract_intervals(a, b):
    """Return the integers covered by a but not by b; see spec/calc/intervals.md."""
    raise NotImplementedError


def count_points(intervals):
    """Return the number of distinct integers covered; see spec/calc/intervals.md."""
    raise NotImplementedError
