"""Descriptive statistics. See spec/calc/stats.md."""


def mean(values):
    """Return the arithmetic mean; see spec/calc/stats.md."""
    raise NotImplementedError


def median(values):
    """Return the median; see spec/calc/stats.md."""
    raise NotImplementedError


def mode(values):
    """Return the most frequent value; see spec/calc/stats.md."""
    raise NotImplementedError


def percentile(values, p):
    """Return the p-th percentile; see spec/calc/stats.md."""
    raise NotImplementedError


def variance(values, sample=False):
    """Return the population or sample variance; see spec/calc/stats.md."""
    raise NotImplementedError


def stdev(values, sample=False):
    """Return the population or sample standard deviation; see spec/calc/stats.md."""
    raise NotImplementedError
