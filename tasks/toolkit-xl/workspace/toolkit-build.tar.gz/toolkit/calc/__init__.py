"""Facade of the toolkit.calc package. See spec/calc/PACKAGE.md."""

from .expr import ExprError, ExprNameError, ExprSyntaxError, evaluate
from .intervals import (
    count_points,
    intersect_intervals,
    merge_intervals,
    subtract_intervals,
)
from .stats import mean, median, mode, percentile, stdev, variance
from .units import (
    UnitError,
    convert,
    convert_text,
    format_number,
    format_quantity,
    parse_quantity,
    unit_family,
)

__all__ = [
    "ExprError",
    "ExprNameError",
    "ExprSyntaxError",
    "UnitError",
    "convert",
    "convert_text",
    "count_points",
    "evaluate",
    "format_number",
    "format_quantity",
    "intersect_intervals",
    "mean",
    "median",
    "merge_intervals",
    "mode",
    "parse_quantity",
    "percentile",
    "stat_expr",
    "stdev",
    "subtract_intervals",
    "unit_family",
    "variance",
]


def stat_expr(expression, values):
    """Evaluate expression with the statistics of values as variables; see spec/calc/PACKAGE.md."""
    raise NotImplementedError
