"""Arithmetic expression evaluator. See spec/calc/expr.md."""


class ExprError(ValueError):
    """Base class of the errors raised by evaluate; see spec/calc/expr.md."""


class ExprSyntaxError(ExprError):
    """The expression is malformed; see spec/calc/expr.md."""


class ExprNameError(ExprError):
    """The expression uses an unknown variable or function; see spec/calc/expr.md."""


def evaluate(expression, variables=None):
    """Evaluate an arithmetic expression and return a float; see spec/calc/expr.md."""
    raise NotImplementedError
