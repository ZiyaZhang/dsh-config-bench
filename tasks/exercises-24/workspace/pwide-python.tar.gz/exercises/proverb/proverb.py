def proverb():
    pass
