def total(basket):
    pass
